# lab_2.py
#
# Author:He Bai     
# Student ID:997677931
#
# This library was written as part of Physics 102: Computational Laboratory
# in Physics, Fall 2014.

# import required libraries
import numpy as np


# Exercise 1
def make_regular_array(x, num_points = 100):
    """create numpy array with evenly spaced points
    Arguments
    =========
    x = numpy array
    num_points = integer - optional argument, default value = 100

    Returns
    ======
    1D numpy array with evenly spaced number of points, and
    same support as x
    """
    # start your code here
    first = x[0]
    last = x[len(x) - 1]
    step = (last - first) / float(num_points-1)
    arr = np.arange(first, last + step, step);
    return arr


# Exercise 2
def calc_line(x, m, b):
    """calculate values predicted by our straight line model
    Arguments
    ==========
    x = numpy array
    m = float - slope of the straight line model
    b = float - intercept

    Returns
    =======
    numpy array with the same size as x
    """
    # start your code here
    def fx(a):
        return a * m + b
    return np.apply_along_axis(fx, 0, x)


# Exercise 3
def find_distance(x, function, args):
    """compute distance between x and predicted values by function
    Arguments
    ==========
    x = numpy array
    function = a python function that takes and returns a numpy array
    args = list of variables that are the arguments for function

    Returns
    ======
    numpy array that denotes the distance between data x and and the function
    """
    # start your code here
    i = x[0]
    o = x[1]
    distance = 0
    for index in range(len(i)):
        result = function(i[index], *args)
        residual = pow((result - o[index]), 2)
        distance = distance + residual
    return np.array([distance])


# You should write your own doc string to denote
# 1) the name of the arguments
# 2) the types of the arguments
# 3) similar info for the returned variables if there is any
# Exercise 4
def make_regular_array_test():
    # start your code here with documentation
    """
    x : test input value, numpy array
    answer is the expected output, numpy array
    """
    x = np.array([1,1,2,100])
    answer = np.array([1.,2.,3.,4.,5.,6.,7.,8.,9.,10.,11.,12.
,13.,14.,15.,16.,17.,18.,19.,20.,21.,22.,23.,24.
,25.,26.,27.,28.,29.,30.,31.,32.,33.,34.,35.,36.
,37.,38.,39.,40.,41.,42.,43.,44.,45.,46.,47.,48.
,49.,50.,51.,52.,53.,54.,55.,56.,57.,58.,59.,60.
,61.,62.,63.,64.,65.,66.,67.,68.,69.,70.,71.,72.
,73.,74.,75.,76.,77.,78.,79.,80.,81.,82.,83.,84.
,85.,86.,87.,88.,89.,90.,91.,92.,93.,94.,95.,96.
,97.,98.,99.,100.])
    testAns = make_regular_array(x)
    if np.array_equal(answer, testAns):
        print "Test Passed"
    else:
        print "Test Failed!"
    return None

def calc_line_test():
    # start your code here with documentation
    """
    x: test input, numpy array
    m: float - slope of the straight line model
    b: float - intercept
    eResult: numpy array, expected result
    aResult: numpy array, actual result
    """
    x = np.arange(0,10)
    m = 3
    b = 7
    eResult = np.array([7,10,13,16,19,22,25,28,31,34])
    aResult = calc_line(x, m, b)
    if np.array_equal(eResult, aResult):
        print "Test Passed"
    else:
        print "Test Failed!"
    return None

def find_distance_test():
    # start your code here with documentation
    """
    x: numpy array, test input
    f: function, test function
    args: array, test input for f
    eResult: numpy array, expected result
    aResult: numpy array, actual result
    """
    x = np.array([[0,1,2,3,5], [1, 2, 5, 10, 26]])

    def f(x, a):
        return a * (x**2)
    args = [2]
    eResult = np.array([650])
    aResult = find_distance(x, f, args)
    if np.array_equal(eResult, aResult):
        print "Test Passed"
    else:
        print "Test Failed!"
    return None
    return None
